package vues;

import javax.swing.JPanel;

public class PanelHeader extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PanelHeader() {

	}

}
