package vues;

import javax.swing.JPanel;

public class PanelHeader extends JPanel {

	public PanelHeader() {

	}

}
