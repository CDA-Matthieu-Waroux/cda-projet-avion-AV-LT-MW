package models;

public class MeteoriteIceBerg extends Meteorite {

	public MeteoriteIceBerg(int pHeight, int pWidth, int pVitesse, String pLienPhoto) {
		super(pHeight, pWidth, pVitesse, pLienPhoto, 4);
		// TODO Auto-generated constructor stub
	}

}
