package models;

public class MeteoriteFeu extends Meteorite {

	public MeteoriteFeu(int pHeight, int pWidth, int pVitesse, String pLienPhoto) {
		super(pHeight, pWidth, pVitesse, pLienPhoto, 2, 1);

	}

}
