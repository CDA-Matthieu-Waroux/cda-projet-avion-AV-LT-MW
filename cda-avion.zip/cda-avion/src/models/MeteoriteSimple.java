package models;

public class MeteoriteSimple extends Meteorite {

	public MeteoriteSimple(int pHeight, int pWidth, int pVitesse, String pLienPhoto) {
		super(pHeight, pWidth, pVitesse, pLienPhoto, 1, 2);
	}

}
