package models;

public class MeteoriteGlace extends Meteorite {

	public MeteoriteGlace(int pHeight, int pWidth, int pVitesse, String pLienPhoto) {
		super(pHeight, pWidth, pVitesse, pLienPhoto, 2);

	}

}
