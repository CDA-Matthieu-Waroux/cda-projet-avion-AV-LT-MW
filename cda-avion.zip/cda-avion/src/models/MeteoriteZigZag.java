package models;

public class MeteoriteZigZag extends Meteorite {

	public MeteoriteZigZag(int pHeight, int pWidth, int pVitesse, String pLienPhoto) {
		super(pHeight, pWidth, pVitesse, pLienPhoto, 1);
	}

}
