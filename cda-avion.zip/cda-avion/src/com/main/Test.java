package com.main;

import vues.FenetreNom;

public class Test {

	public static void main(String[] args) {
		new FenetreNom();

	}
}
