package com.main;

import vues.MaFenetre;

public class Test {

	public static void main(String[] args) {
		new MaFenetre();
	}
}
